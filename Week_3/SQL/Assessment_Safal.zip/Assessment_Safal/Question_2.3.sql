USE SpartaAcademy;

------------ Question 2.3 -------------


----- Adding the London Academy -----

INSERT INTO [Academies]
           ([AcademyName])
     VALUES
           ('London')


----- Adding the Data Stream -----

INSERT INTO [CourseCatalog]
           ([CourseName]
           ,[Duration])
     VALUES
           ('Data',
           8)


----- Adding New Trainer for Data -----

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           )
     VALUES
	 		('Isabella','Jones','T')

----- Adding a new TA for Data ----

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           )
     VALUES
	 		('Training','Assistant','A')

----- Adding Current Spartans in the Data Stream ----

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           
           )
     VALUES
	 	   ('Sahal','Nurain','S')

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           
           )
     VALUES
	 	   ('Safal','Mukhia','S')

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           
           )
     VALUES
	 	   ('Oscar','China','S')

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           
           )
     VALUES
	 	   ('Viki','Patel','S')

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           
           )
     VALUES
	 	   ('Daniel','Hughes','S')

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           
           )
     VALUES
	 	   ('Jeevan','Sandhu','S')

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           
           )
     VALUES
	 	   ('Hudhayfee','Hassan','S')

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           
           )
     VALUES
	 	   ('Avnish','Hirani','S')

INSERT INTO [Employees]
           ([FirstName]
           ,[LastName]
           ,[EmployeeType]
           
           )
     VALUES
	 	   ('Sarmi','Ranjan','S')


